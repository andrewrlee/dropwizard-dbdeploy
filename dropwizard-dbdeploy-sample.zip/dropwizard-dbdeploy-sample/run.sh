echo "##########################";
echo "Dropping database!";
echo "##########################";
java -jar dropwizard-dbdeploy-sample-0.0.1-SNAPSHOT.jar db run -s db/scripts/drop.sql sample.create.yaml

echo "##########################";
echo "Creating database!";
echo "##########################";
java -jar dropwizard-dbdeploy-sample-0.0.1-SNAPSHOT.jar db run -s db/scripts/createSchemaVersionTable.mysql.sql sample.yaml

echo "##########################";
echo "running upgrade";
echo "##########################";
java -jar dropwizard-dbdeploy-sample-0.0.1-SNAPSHOT.jar db upgrade sample.yaml
