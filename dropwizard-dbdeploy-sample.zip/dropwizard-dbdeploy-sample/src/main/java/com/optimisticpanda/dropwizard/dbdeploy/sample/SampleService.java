package com.optimisticpanda.dropwizard.dbdeploy.sample;

import uk.co.optimisticpanda.dropwizard.DbDeployBundle;
import uk.co.optimisticpanda.dropwizard.DbDeployDatabaseConfiguration;

import com.yammer.dropwizard.Service;
import com.yammer.dropwizard.config.Bootstrap;
import com.yammer.dropwizard.config.Environment;

public class SampleService extends Service<SampleConfiguration> {
    @Override
    public void initialize(Bootstrap<SampleConfiguration> bootstrap) {
        bootstrap.addBundle(new DbDeployBundle<SampleConfiguration>() {
            public DbDeployDatabaseConfiguration getDatabaseConfiguration(SampleConfiguration configuration) {
                return configuration.getDatabaseConfiguration();
            }
        });
    }

    @Override
    public void run(SampleConfiguration configuration, Environment environment) throws Exception {
      
    }

    public static void main(String[] args) throws Exception {
        new SampleService().run(args);
    }
    
}