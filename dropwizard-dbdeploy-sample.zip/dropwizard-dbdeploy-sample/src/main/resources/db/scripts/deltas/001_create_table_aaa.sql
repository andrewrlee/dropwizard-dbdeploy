
CREATE TABLE aaa(
  change_number BIGINT NOT NULL,
  change_set VARCHAR(100) NOT NULL,
  complete_dt TIMESTAMP NOT NULL,
  applied_by VARCHAR(100) NOT NULL,
  description VARCHAR(500) NOT NULL
);