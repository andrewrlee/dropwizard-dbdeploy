
CREATE database IF NOT EXISTS demando;
use demando;
drop table if exists changelog ;
drop database if exists demando;
CREATE database IF NOT EXISTS demando;
