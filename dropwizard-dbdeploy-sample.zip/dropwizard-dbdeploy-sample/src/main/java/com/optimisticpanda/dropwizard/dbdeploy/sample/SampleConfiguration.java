package com.optimisticpanda.dropwizard.dbdeploy.sample;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import uk.co.optimisticpanda.dropwizard.DbDeployDatabaseConfiguration;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yammer.dropwizard.config.Configuration;

public class SampleConfiguration extends Configuration {
    @Valid
    @NotNull
    @JsonProperty
    private DbDeployDatabaseConfiguration database = new DbDeployDatabaseConfiguration();

    public DbDeployDatabaseConfiguration getDatabaseConfiguration() {
        return database;
    }
}